package com.example.assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.assignment1.databinding.ActivityMainBinding
import androidx.appcompat.app.AlertDialog.Builder as AlertDialogBuilder

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var rightAns: String? = null
    private var rightAnsCount = 0
    private var quizCount = 1
    private val dataSet = mutableListOf(
        mutableListOf("Who is the most honorable person in Seven kingdoms?", "Ned Stark","Jon Arryn","Jaehaerys I Targaryen" )

    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        showQues()
    }
    fun showQues(){
        val data = dataSet[0]
        binding.questions.text = data[0]
        rightAns = data[1]
        binding.checkBox.text = data[1]
        binding.checkBox2.text = data[2]
        binding.checkBox3.text = data[3]
    }
    fun checkAns(view: View){
        val button: Button = findViewById(view.id)
        val btText = button.text.toString()
        val alertTitle: String
        if(btText == rightAns){
            alertTitle = "Correct!"
        }
        else{
            alertTitle = "Wrong"
        }
        AlertDialog.Builder(this)
            .setTitle(alertTitle)
            .setMessage("Answer: $rightAns")
            .setPositiveButton("ok"){dialogInterface, i->}
            .setCancelable(false)
            .show()

    }
}